///Numeros
function n0(){
    let num1 = document.calculator.ans.value+='0';
    num1 +='0';
}
function n1(){
    let num1 = document.calculator.ans.value+='1';
    num1 +='1';
}
function n2(){
    let num2 = document.calculator.ans.value+='2';
    num2 +='2';
}
function n3(){
    let num3 = document.calculator.ans.value+='3';
    num3 +='3';
}
function n4(){
    let num4 = document.calculator.ans.value+='4';
    num4 +='4';
}
function n5(){
    let num5 = document.calculator.ans.value+='5';
    num1 +='5';
}
function n6(){
    let num6 = document.calculator.ans.value+='6';
    num6 +='6';
}
function n7(){
    let num7 = document.calculator.ans.value+='7';
    num7 +='7';
}
function n8(){
    let num8 = document.calculator.ans.value+='8';
    num8 +='8';
}
function n9(){
    let num9 = document.calculator.ans.value+='9';
    num9 +='9';
}

///demas
function suma(){
    let suma = document.calculator.ans.value += '+';
    suma += '+';
}
function resta(){
    let resta = document.calculator.ans.value += '-';
    resta += '-';
}
function valor(){
    let tot=document.calculator.ans.value =eval(document.calculator.ans.value);
    tot=eval(document.calculator.ans.value);
}